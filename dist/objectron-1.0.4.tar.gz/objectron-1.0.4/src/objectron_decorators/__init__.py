from .decorators import proxy_class

__all__ = ["proxy_class"]
